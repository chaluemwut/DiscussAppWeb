-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `andoird`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `cat_id`
-- 

CREATE TABLE `cat_id` (
  `cat_id` int(20) NOT NULL auto_increment,
  `cat_topic` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `date_time` text NOT NULL,
  `num_reply` int(20) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

-- 
-- dump ตาราง `cat_id`
-- 

INSERT INTO `cat_id` VALUES (42, 'อุปกรณ์อิเล็กทรอนิกส์', 'staff1', '09 พฤษภาคม 2558 00:05:42', 6);
INSERT INTO `cat_id` VALUES (43, 'รถยนต์', 'admin2', '09 พฤษภาคม 2558 00:07:30', 5);
INSERT INTO `cat_id` VALUES (44, 'สัตว์เลี้ยง', 'admin3', '09 พฤษภาคม 2558 00:09:13', 6);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `post`
-- 

CREATE TABLE `post` (
  `topic_id` int(20) NOT NULL auto_increment,
  `cat_id` int(20) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `owner` varchar(50) NOT NULL,
  `date_time` text NOT NULL,
  `img` text NOT NULL,
  `top_id` int(10) NOT NULL,
  `num_reply` int(20) NOT NULL,
  PRIMARY KEY  (`topic_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=82 ;

-- 
-- dump ตาราง `post`
-- 

INSERT INTO `post` VALUES (58, 44, 'ชื่อเจ้า บูล', 'น่ารักมากๆๆๆๆๆๆๆๆ', 'nuttapon', '09 พฤษภาคม 2558 00:18:57', '1431105537817.png', 2, 0);
INSERT INTO `post` VALUES (57, 43, 'กว่าจะได้มา', 'สวยผุดๆๆๆ', 'nuttapon', '09 พฤษภาคม 2558 00:18:14', '1431105494982.png', 0, 0);
INSERT INTO `post` VALUES (56, 43, 'รถผมเอง', 'สวยมากนะ', 'nuttapon', '09 พฤษภาคม 2558 00:17:50', '1431105470832.png', 0, 0);
INSERT INTO `post` VALUES (55, 42, 'โทรศัพท์มาใหม่ ', 'อยากขายมากๆๆ', 'nuttapon', '09 พฤษภาคม 2558 00:16:43', '1431105403746.png', 0, 0);
INSERT INTO `post` VALUES (53, 44, 'ขายลูกสุนัข', 'ราคาเปนกันเอง', 'admin', '09 พฤษภาคม 2558 00:13:43', '1431105223366.png', 0, 1);
INSERT INTO `post` VALUES (54, 42, 'ขายโน๊ตบุ๊ค', 'สนใจ 084-3915843', 'nuttapon', '09 พฤษภาคม 2558 00:15:29', '1431105329460.png', 1, 0);
INSERT INTO `post` VALUES (52, 44, 'ขายสุนัข', 'ราคาดี ๆๆ', 'admin', '09 พฤษภาคม 2558 00:13:06', '1431105186040.png', 1, 2);
INSERT INTO `post` VALUES (51, 43, 'รถยน', 'สวยๆ', 'admin', '09 พฤษภาคม 2558 00:12:10', '1431105130553.png', 1, 0);
INSERT INTO `post` VALUES (50, 43, 'รถออกมาใหม่', 'สวยๆๆทั้งนั้น', 'admin', '09 พฤษภาคม 2558 00:11:28', '1431105088029.png', 0, 0);
INSERT INTO `post` VALUES (49, 42, 'ขายโน๊ตบุ๊ค', 'ราคาเป็นกันเอง', 'admin', '09 พฤษภาคม 2558 00:10:40', '1431105040357.png', 0, 0);
INSERT INTO `post` VALUES (48, 42, 'โทรศัพท์', 'สวยๆๆๆๆ', 'admin', '09 พฤษภาคม 2558 00:10:01', '1431105001750.png', 0, 0);
INSERT INTO `post` VALUES (59, 44, 'ขายสุนัข', 'ราคา 80000', 'nuttapon', '09 พฤษภาคม 2558 00:19:31', '1431105571524.png', 0, 1);
INSERT INTO `post` VALUES (60, 44, 'ขายควาย8ขา', 'เเเ', 'supadate', '11 พฤษภาคม 2558 23:36:46', '1431362206981.png', 0, 0);
INSERT INTO `post` VALUES (61, 44, 'ขายควาย8ขา', '', 'supadate', '11 พฤษภาคม 2558 23:39:18', '1431362358342.png', 1, 0);
INSERT INTO `post` VALUES (62, 43, 'ขายถูกๆๆ', 'ราคา 10000 บาทเอง', 'admin1', '31 พฤษภาคม 2558 18:03:57', '1433070237976.png', 0, 0);
INSERT INTO `post` VALUES (70, 42, 'ขายมือถือ', 'ราคากันเอง', 'admin', '19 มิถุนายน 2558 23:58:11', '1434733091291.png', 0, 0);
INSERT INTO `post` VALUES (71, 42, 'ขายเครื่องเสียง', 'ใช้มา2ปีไม่มีรอย', '1234', '20 มิถุนายน 2558 00:47:20', '1434736067925.png', 0, 0);
INSERT INTO `post` VALUES (72, 44, 'ถูกๆๆๆ', 'สวยๆๆ ทั้งนั้น', 'nuttapon', '21 มิถุนายน 2558 21:57:38', '1434898658065.png', 0, 0);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `post_reply`
-- 

CREATE TABLE `post_reply` (
  `id` int(20) NOT NULL auto_increment,
  `topic_id` int(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `date_time` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

-- 
-- dump ตาราง `post_reply`
-- 

INSERT INTO `post_reply` VALUES (57, 53, 'admin', 'ตัวละ 10000', '09 พฤษภาคม 2558 00:14:25');
INSERT INTO `post_reply` VALUES (61, 59, 'nuttapon', 'น่ารักมากๆ', '21 มิถุนายน 2558 01:00:55');
INSERT INTO `post_reply` VALUES (62, 77, 'aaaa', 'นาน', '22 มิถุนายน 2558 09:18:31');
INSERT INTO `post_reply` VALUES (63, 77, 'aaaa', 'านารนสา', '22 มิถุนายน 2558 09:18:46');
INSERT INTO `post_reply` VALUES (64, 78, 'aaaa', 'eeeww', '22 มิถุนายน 2558 09:24:50');
INSERT INTO `post_reply` VALUES (65, 74, 'nuttapon', '11111', '22 มิถุนายน 2558 16:36:06');
INSERT INTO `post_reply` VALUES (59, 52, 'supadate', 'หมาหรือ ม้าแพงชิบหาย', '11 พฤษภาคม 2558 23:35:37');
INSERT INTO `post_reply` VALUES (60, 64, 'admin', 'ขายยยยยยยยย', '19 มิถุนายน 2558 23:55:41');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_user`
-- 

CREATE TABLE `tb_user` (
  `user_id` int(10) NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `userAddress` text NOT NULL,
  `userTel` varchar(30) NOT NULL,
  `userEmail` varchar(50) NOT NULL,
  `cat_topic` varchar(100) NOT NULL,
  `role_id` int(20) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

-- 
-- dump ตาราง `tb_user`
-- 

INSERT INTO `tb_user` VALUES (1, 'nuttapon', '123456', 'นายณัฐพล ผงบุญตา', 'เลย', '0843915843', 'nut_tapon_12@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (3, '123456', '123456', 'ffffffffffff', 'ffffffffffffff', '7894561237', 'ratchaneemanat@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (4, 'supadate', '1234qwer', 'ศุภเดช', 'ขอนแก่น', '0836608476', 'club-zaa_mai@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (40, 'aaaa', 'aaaa', 'aaaa', 'loei', '0843915843', '1234@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (20, 'pong', '123456', 'โป้ง', 'loei', '0843915843', 'ratchaneemanat@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (35, 'admin2', '1234', 'admin2', 'null', 'null', 'null', 'รถยนต์', 2);
INSERT INTO `tb_user` VALUES (7, '1234', '1234', 'dfff', 'dssdsd', '7894561237', '12345@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (8, 'admin', '12345', 'admin', 'null', 'null', 'null', '0', 1);
INSERT INTO `tb_user` VALUES (32, 'mmmm', 'mmmm', 'สาวๆๆ', 'เลย', '7894561237', 'lovezalonezaza@hotmail.com', '0', 3);
INSERT INTO `tb_user` VALUES (34, 'staff1', '1234', 'staff1', 'null', 'null', 'null', 'อุปกรณ์อิเล็กทรอนิกส์', 2);
INSERT INTO `tb_user` VALUES (36, 'admin3', '1234', 'admin3', 'null', 'null', 'null', 'สัตว์เลี้ยง', 2);
INSERT INTO `tb_user` VALUES (41, 'superunderflow', '1234', 'ณัฐพล', 'ขอนแก่น', '0843915843', '123abc@hotmail.com', 'No', 3);
INSERT INTO `tb_user` VALUES (43, '12345', '12345', '12345', 'ชชชช', '0843915843', '789@hotmail.com', 'No', 3);
